﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StudentSystem.Data
{
    public enum ContentType
    {
        Appllication = 1,
        PDF = 2,
        ZIP = 3
    }
}
